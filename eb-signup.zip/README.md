# eb_django_express_signup

This repository contains the Python 3.x code base of a small web application for a [tutorial](https://github.com/CCBDA-UPC/Assignments-2022/blob/origin/Lab04.md) that instructs on how to deploy a web app on PaaS **AWS Beanstalk**. The web app interacts with **Amazon DynamoDB**, **Amazon Simple Notification Service** and **Amazon Cloud Front**.

*eb_django_express_signup* follows the popular Python framework [Django](https://www.djangoproject.com/).
